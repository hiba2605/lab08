
module Basys3_Memory_Demo (
    input wire clk,
    input wire btnC,
    input wire btnU,
    input wire btnR,
    input wire btnL,
    input wire [15:0] sw,
    output wire [15:0] led,
    output wire [6:0] seg,
    output wire [3:0] an,
    output wire dp
);

    // Controller states
    localparam IDLE       = 3'd0;
    localparam STORE_MEM  = 3'd1;
    localparam WRITE_LED  = 3'd2;
    localparam READ_MEM   = 3'd3;

    reg [2:0] state;

    // The two memory locations used in this test
    reg [31:0] selected_address;
    reg [31:0] stored_value;
    reg [31:0] display_value;

    reg btnU_prev;
    reg btnR_prev;
    reg btnL_prev;

    wire btnU_press = btnU && !btnU_prev;
    wire btnR_press = btnR && !btnR_prev;
    wire btnL_press = btnL && !btnL_prev;

    reg readEnable;
    reg writeEnable;
    reg [31:0] address;
    reg [31:0] writeData;
    wire [31:0] readData;

    // Memory-mapped memory and peripheral interface
    addressDecoderTop system (
        .clk(clk),
        .rst(btnC),
        .address(address),
        .readEnable(readEnable),
        .writeEnable(writeEnable),
        .writeData(writeData),
        .switches(sw),
        .readData(readData),
        .leds(led)
    );

    // Display the last number read from memory
    Seven_Segment_Display display (
        .clk(clk),
        .value(display_value[15:0]),
        .seg(seg),
        .an(an),
        .dp(dp)
    );

    // Select address and control the bus
    always @(*) begin
        address = selected_address;
        writeData = stored_value;
        readEnable = 1'b0;
        writeEnable = 1'b0;

        case (state)
            STORE_MEM: begin
                address = selected_address;
                writeEnable = 1'b1;
            end

            WRITE_LED: begin
                address = 32'd528;
                writeEnable = 1'b1;
            end

            READ_MEM: begin
                address = selected_address;
                readEnable = 1'b1;
            end

            default: begin
                address = selected_address;
            end
        endcase
    end

    // Button edge detection and controller
    always @(posedge clk) begin
        if (btnC) begin
            state <= IDLE;
            selected_address <= 32'd5;
            stored_value <= 32'd0;
            display_value <= 32'd0;

            btnU_prev <= 1'b0;
            btnR_prev <= 1'b0;
            btnL_prev <= 1'b0;
        end else begin
            btnU_prev <= btnU;
            btnR_prev <= btnR;
            btnL_prev <= btnL;

            case (state)
                IDLE: begin
                    if (btnR_press) begin
                        if (selected_address == 32'd5)
                            selected_address <= 32'd6;
                        else
                            selected_address <= 32'd5;
                    end
                    else if (btnU_press) begin
                        stored_value <= {24'd0, sw[7:0]};
                        state <= STORE_MEM;
                    end
                    else if (btnL_press) begin
                        state <= READ_MEM;
                    end
                end

                STORE_MEM: begin
                    // Data Memory writes at this clock edge.
                    state <= WRITE_LED;
                end

                WRITE_LED: begin
                    // Also show the stored number on the LEDs.
                    state <= IDLE;
                end

                READ_MEM: begin
                    // Capture the combinational memory read result.
                    display_value <= readData;
                    state <= IDLE;
                end

                default: begin
                    state <= IDLE;
                end
            endcase
        end
    end

endmodule
