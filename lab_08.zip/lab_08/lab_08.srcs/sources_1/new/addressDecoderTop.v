
`timescale 1ns / 1ps

module addressDecoderTop(
    input         clk,
    input         rst,
    input  [31:0] address,
    input         readEnable,
    input         writeEnable,
    input  [31:0] writeData,
    input  [15:0] switches,
    output [31:0] readData,
    output [15:0] leds
);

    // Address decoder signals
    wire DataMemSelect;
    wire LEDSelect;
    wire SwitchSelect;

    wire DataMemRead;
    wire DataMemWrite;
    wire LEDWrite;
    wire SwitchReadEnable;

    // Read data from each device
    wire [31:0] memReadData;
    wire [31:0] switchReadData;

    // Address decoder
    Address_Decoder decoder (
        .address(address),
        .MemRead(readEnable),
        .MemWrite(writeEnable),
        .DataMemSelect(DataMemSelect),
        .LEDSelect(LEDSelect),
        .SwitchSelect(SwitchSelect),
        .DataMemRead(DataMemRead),
        .DataMemWrite(DataMemWrite),
        .LEDWrite(LEDWrite),
        .SwitchReadEnable(SwitchReadEnable)
    );

    // Data Memory
    Data_Memory data_mem (
        .clk(clk),
        .MemWrite(DataMemWrite),
        .address(address),
        .write_data(writeData),
        .read_data(memReadData)
    );

    // LED interface: the Lab 5 switches module
    switches led_interface (
        .clk(clk),
        .rst(rst),
        .writeData(writeData),
        .writeEnable(LEDWrite),
        .readEnable(1'b0),
        .memAddress(address[31:2]),
        .readData(),
        .leds(leds)
    );

    
    leds switch_interface (
        .clk(clk),
        .rst(rst),
        .btns(16'b0),
        .writeData(32'b0),
        .writeEnable(1'b0),
        .readEnable(SwitchReadEnable),
        .memAddress(address[31:2]),
        .switches(switches),
        .readData(switchReadData)
    );

    // Read-data multiplexer
    assign readData = DataMemRead    ? memReadData :
                      SwitchReadEnable ? switchReadData :
                      32'b0;

endmodule
