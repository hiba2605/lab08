
`timescale 1ns / 1ps

module Address_Decoder (
    input  [31:0] address,
    input         MemRead,
    input         MemWrite,

    output        DataMemSelect,
    output        LEDSelect,
    output        SwitchSelect,

    output        DataMemRead,
    output        DataMemWrite,
    output        LEDWrite,
    output        SwitchReadEnable
);

   
    assign DataMemSelect = (address[9:8] == 2'b00) ||
                           (address[9:8] == 2'b01);

    assign LEDSelect     = (address[9:8] == 2'b10);

    assign SwitchSelect  = (address[9:8] == 2'b11);

   
    assign DataMemRead  = MemRead  & DataMemSelect;
    assign DataMemWrite = MemWrite & DataMemSelect;

    assign LEDWrite        = MemWrite & LEDSelect;
    assign SwitchReadEnable = MemRead & SwitchSelect;

endmodule
