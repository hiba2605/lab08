
`timescale 1ns / 1ps

module Data_Memory (
    input         clk,
    input         MemWrite,
    input  [31:0] address,
    input  [31:0] write_data,
    output [31:0] read_data
);

    
    reg [31:0] memory [0:511];

    
    wire [8:0] word_address;
    assign word_address = address[8:0];

    
    always @(posedge clk) begin
        if (MemWrite) begin
            memory[word_address] <= write_data;
        end
    end

   
    assign read_data = memory[word_address];

endmodule