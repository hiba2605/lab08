
`timescale 1ns / 1ps

module Address_Decoder_tb;

    reg  [31:0] address;
    reg         MemRead;
    reg         MemWrite;

    wire DataMemSelect;
    wire LEDSelect;
    wire SwitchSelect;
    wire DataMemRead;
    wire DataMemWrite;
    wire LEDWrite;
    wire SwitchReadEnable;

    Address_Decoder uut (
        .address(address),
        .MemRead(MemRead),
        .MemWrite(MemWrite),
        .DataMemSelect(DataMemSelect),
        .LEDSelect(LEDSelect),
        .SwitchSelect(SwitchSelect),
        .DataMemRead(DataMemRead),
        .DataMemWrite(DataMemWrite),
        .LEDWrite(LEDWrite),
        .SwitchReadEnable(SwitchReadEnable)
    );

    initial begin
        // Initialize inputs
        address  = 0;
        MemRead  = 0;
        MemWrite = 0;

        // Test 1: Data Memory write
        #10;
        address  = 32'd5;
        MemWrite = 1;
        #10;
        MemWrite = 0;

        // Test 2: Data Memory read
        address = 32'd300;
        MemRead = 1;
        #10;
        MemRead = 0;

        // Test 3: LED write
        address  = 32'd528;
        MemWrite = 1;
        #10;
        MemWrite = 0;

        // Test 4: Switch read
        address = 32'd848;
        MemRead = 1;
        #10;
        MemRead = 0;

        // Test 5: Upper address bits are ignored
        address  = 32'hFFFFFE05;
        MemWrite = 1;
        #10;
        MemWrite = 0;

        #10;
        $finish;
    end

endmodule
