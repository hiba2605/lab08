`timescale 1ns / 1ps

module Data_Memory_tb;

   
    reg clk;
    reg MemWrite;
    reg [31:0] address;
    reg [31:0] write_data;
    wire [31:0] read_data;

    Data_Memory uut (
        .clk(clk),
        .MemWrite(MemWrite),
        .address(address),
        .write_data(write_data),
        .read_data(read_data)
    );

    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

   
    initial begin
        
        MemWrite = 0;
        address = 0;
        write_data = 0;

        @(negedge clk);
        address = 5;
        write_data = 32'h12345678;
        MemWrite = 1;

        @(negedge clk);
        MemWrite = 0;

     
        @(negedge clk);
        address = 10;
        write_data = 32'hABCDEF01;
        MemWrite = 1;

        @(negedge clk);
        MemWrite = 0;

        
        @(negedge clk);
        address = 5;

       
        #10;

        
        $finish;
    end

endmodule