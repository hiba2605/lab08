
`timescale 1ns / 1ps

module MemorySystem_tb;

    reg clk;
    reg rst;
    reg [31:0] address;
    reg readEnable;
    reg writeEnable;
    reg [31:0] writeData;
    reg [15:0] switches;

    wire [31:0] readData;
    wire [15:0] leds;

    integer errors;

    // Instantiate the complete memory system
    addressDecoderTop uut (
        .clk(clk),
        .rst(rst),
        .address(address),
        .readEnable(readEnable),
        .writeEnable(writeEnable),
        .writeData(writeData),
        .switches(switches),
        .readData(readData),
        .leds(leds)
    );

    // Clock generation: 10 ns period
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize inputs
        rst = 1;
        address = 0;
        readEnable = 0;
        writeEnable = 0;
        writeData = 0;
        switches = 0;
        errors = 0;

        // Reset peripherals
        repeat (2) @(negedge clk);
        rst = 0;

        // Test 1: Write to Data Memory
        @(negedge clk);
        address = 32'd5;
        writeData = 32'h12345678;
        writeEnable = 1;

        @(negedge clk);
        writeEnable = 0;

        // Test 2: Read Data Memory
        address = 32'd5;
        readEnable = 1;
        #1;

        if (readData !== 32'h12345678)
            errors = errors + 1;

        @(negedge clk);
        readEnable = 0;

        // Test 3: Write to LEDs
        @(negedge clk);
        address = 32'd528;
        writeData = 32'h0000ABCD;
        writeEnable = 1;

        @(negedge clk);
        writeEnable = 0;
        #1;

        if (leds !== 16'hABCD)
            errors = errors + 1;

        // Test 4: Read Switches
        @(negedge clk);
        address = 32'd848;
        switches = 16'h5678;
        readEnable = 1;
        #1;

        if (readData !== 32'h00005678)
            errors = errors + 1;

        @(negedge clk);
        readEnable = 0;

        #10;
        $finish;
    end

endmodule
